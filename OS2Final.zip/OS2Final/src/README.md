Jordan Prudhomme - Worked on linking the filters and fixed errors after merging our two parts

Osamah Mandawi - Worked on repl and helped fix the errors after merging the our parts