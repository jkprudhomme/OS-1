package cs131.pa1.filter.sequential;

import java.util.LinkedList;

/**
 * 
 * @author Osamah
 *
 */
public class grep extends SequentialFilter {
	private String line;

	/**
	 * 
	 * @param line
	 *            the search string
	 */
	public grep(String line) {
		this.line = line;
	}

	@Override
	public void process() {
		output = new LinkedList<String>();
		String parts[] = line.trim().split(" ");

		String[] found = input.poll().trim().split("\n");
		for (int i = 0; i < found.length; i++) {
			/*
			 * checks which of the input's lines has the search string and adds it to the
			 * output queue
			 */
			if (found[i].contains(parts[1])) {
				output.add(found[i]);
			}
		}
	}

	@Override
	/**
	 * Unused... extension requirement
	 */
	protected String processLine(String line) {
		return null;
	}

}