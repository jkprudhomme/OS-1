package cs131.pa1.filter.sequential;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

/**
 * 
 * @author Osamah
 *
 */
public class write extends SequentialFilter {
	private String line;

	/**
	 * 
	 * @param line
	 *            the name of the file to write the input in
	 */
	public write(String line) {
		this.line = line;
	}

	@Override
	public void process() {
		/*
		 * creates Path using line and writes using input
		 */

		String send = "";
		while (!input.isEmpty()) {
			send += input.poll() + "\n";
		}
		send = send.substring(0, send.length() - 1);
		File fileNeeded = new File(
				SequentialREPL.currentWorkingDirectory + FILE_SEPARATOR + line.replaceAll("> ", "").trim());
		boolean exists = fileNeeded.exists();
		if (exists) {
			writeTo(fileNeeded, send);
		} else {
			create(fileNeeded, send);
		}
	}

	private static void create(File address, String content) {
		/*
		 * For a new file
		 */
		FileWriter fw = null;
		try {
			address.createNewFile();// creates the new file
			fw = new FileWriter(address);
			fw.write(content);
			fw.flush();
			fw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private static void writeTo(File putter, String content) {

		/*
		 * for overwriting a file
		 */
		try {
			FileWriter fw = new FileWriter(putter);
			fw.write(content);
			fw.flush();
			fw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Override
	/**
	 * Unused... extension requirement
	 */
	protected String processLine(String line) {
		return null;
	}

}