package cs131.pa1.filter.sequential;

import java.util.*;

import cs131.pa1.filter.Message;

/**
 * 
 * @author Osamah
 *
 */
public class uniq extends SequentialFilter {
	private String line;

	/**
	 * 
	 * @param line
	 *            unused... just an extension requirement
	 */
	public uniq(String line) {
		this.line = line;
	}

	@Override
	public void process() {
		/*
		 * @see grep.java same idea just filters out duplicates
		 */
		output = new LinkedList<String>();
		String[] disAttach = input.poll().split("\n");
		Set<String> hashee = new LinkedHashSet<String>(); // create a new hash set
		List<String> disAttachToList = Arrays.asList(disAttach); // convert disAttach to a list
		hashee.addAll(disAttachToList); // add disAttach, the list, into the hash set
		for (String lines : hashee) {
			output.add(lines);
		}
	}

	@Override
	/**
	 * Unused... extension requirement
	 */
	protected String processLine(String line) {
		return null;
	}

}
