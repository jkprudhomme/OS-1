package cs131.pa1.filter.sequential;

import java.util.LinkedList;
import cs131.pa1.filter.Message;

/**
 * 
 * @author Osamah
 *
 */
public class wc extends SequentialFilter {
	private String line;

	/**
	 * 
	 * @param line
	 *            unused... just a java requirement
	 */
	public wc(String line) {
		this.line = line;
	}

	@Override
	public void process() {
		/*
		 * @see grep.java & uniq.java
		 * 
		 */
		output = new LinkedList<String>();
		int LC = 0, WC = 0, CC = 0;
		while (!input.isEmpty()) {
			String[] countLines = input.poll().split("\n");
			for (int i = 0; i < countLines.length; i++) {
				if (!countLines[i].isEmpty()) {
					LC++; // count each line after original input was split at line ends
					String lines = countLines[i].replaceAll("\\s", "__space__"); // for the ASCII test that uses ASCII
																					// 32-- space
					String[] countWords = lines.split(" ");
					for (int j = 0; j < countWords.length; j++) {
						if (!countWords[j].equals("__space__")) { // also for the ASCII test
							WC++; // count each word after original input was split at line ends
							CC += countWords[j].length();
						} else {
							CC++;
						}
					}
				}
			}
		}
		output.add(LC + " " + WC + " " + CC);

	}

	@Override
	/**
	 * Unused... extension requirement
	 */
	protected String processLine(String line) {
		return null;
	}

}
