package cs131.pa1.filter.sequential;

/**
 * 
 * @author Osamah
 *
 */
public class pwd extends SequentialFilter {
	private String line;

	/**
	 * 
	 * @param line
	 *            current working directory
	 */
	public pwd(String line) {
		this.line = line;
	}

	@Override
	public void process() {
		output.add(line);
	}

	@Override
	/**
	 * Unused... extension requirement
	 */
	protected String processLine(String line) {
		return null;
	}

}
