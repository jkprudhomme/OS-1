package cs131.pa1.filter.sequential;

/**
 * 
 * @author Osamah
 *
 */
public class cd extends SequentialFilter {
	private String line;

	/**
	 * 
	 * @param line
	 *            the directory to enter
	 */
	public cd(String line) {
		this.line = line;
	}

	@Override
	public void process() {
		int lastFileSeparator = -1;
		for (int i = 0; i < SequentialREPL.currentWorkingDirectory.length(); i++) {
			/*
			 * Find the place of the last file separator to use it when going back to parent
			 * directory
			 * 
			 */
			String some = "" + SequentialREPL.currentWorkingDirectory.charAt(i);
			if (some.equals(FILE_SEPARATOR)) {
				lastFileSeparator = i;
			}
		}
		if (line.equals("..")) {
			/*
			 * goes back to parent directory
			 */
			SequentialREPL.setWorkingDirectory(SequentialREPL.currentWorkingDirectory.substring(0, lastFileSeparator));
		} else if (!line.equals(".")) {
			/*
			 * goes forward to file named -line-
			 */
			SequentialREPL.setWorkingDirectory(SequentialREPL.currentWorkingDirectory += FILE_SEPARATOR + line);
		}
	}

	@Override
	/**
	 * Unused... extension requirement
	 * 
	 */
	protected String processLine(String line) {
		return null;
	}
}