package cs131.pa1.filter.sequential;

import java.io.File;

/**
 * 
 * @author Osamah
 *
 */
public class ls extends SequentialFilter {

	private String line;

	/**
	 * 
	 * @param line
	 *            the current working search directory
	 */
	public ls(String line) {
		this.line = line;
	}

	@Override
	public void process() {
		File address = new File(line);
		String[] children = address.list(); // java finds all inside files/folders in directory

		for (int i = 0; i < children.length; i++) {
			output.add(children[i]);
		}
	}

	@Override
	/**
	 * Unused... extension requirement
	 */
	protected String processLine(String line) {
		return null;
	}

}
