package cs131.pa1.filter.sequential;

import java.io.IOException;
import java.nio.file.*;

/**
 * 
 * @author Osamah
 *
 */
public class cat extends SequentialFilter {
	private String line;

	/**
	 * 
	 * @param line
	 *            the name of the file to run
	 */
	public cat(String line) {
		this.line = line;
	}

	@Override
	public void process() {
		/*
		 * create a new address/path using the given line.
		 * 
		 */
		Path togo = Paths.get(SequentialREPL.currentWorkingDirectory + FILE_SEPARATOR + line);

		if (Files.exists(togo)) {
			/*
			 * add the content of the file to the output if the file exists
			 * 
			 */
			try {
				String text = new String(Files.readAllBytes(togo)).replaceFirst("\\s++$", ""); // trims trail
				output.add(text);
			} catch (IOException e) {
				/*
				 * just a Java requirement
				 * 
				 */
			}
		}
	}

	@Override
	/**
	 * Unused... extension requirement
	 * 
	 */
	protected String processLine(String line) {
		return null;
	}

}
