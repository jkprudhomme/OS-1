package cs131.pa1.filter.sequential;

import java.io.File;

import cs131.pa1.filter.Message;

public class pwd extends SequentialFilter {
	private String line;
	
	public pwd(String line){
		this.line = line;
	}
	
	@Override
	public void process() {
		output.add(line);
//		System.out.print(output.toString().substring(1, output.toString().length()-1));
	}

	@Override
	protected String processLine(String line) {
		// TODO Auto-generated method stub
		return null;
	}

}
