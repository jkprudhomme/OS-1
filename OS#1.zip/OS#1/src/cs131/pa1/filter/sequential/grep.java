package cs131.pa1.filter.sequential;

import java.util.LinkedList;

public class grep extends SequentialFilter {
	private String line;

	public grep(String line) {
		this.line = line;
	}

	@Override
	public void process() {
		output = new LinkedList<String>();
		String parts[] = line.trim().split(" ");
		
		String[] found = input.poll().trim().split("\n");
		for (int i = 0; i < found.length; i++) {

			if (found[i].contains(parts[1])) {
				output.add(found[i]);
			}
		}
	}

	@Override
	protected String processLine(String line) {
		return null;
	}

}