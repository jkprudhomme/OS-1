package cs131.pa1.filter.sequential;

import java.nio.file.*;

import cs131.pa1.filter.Message;

public class cd extends SequentialFilter {
	private String line;

	public cd(String line) {
		this.line = line;
	}

	public void process() {
		int lastFileSeparator = -1;
		for (int i = 0; i < SequentialREPL.currentWorkingDirectory.length(); i++) {
			/*
			 * Find the place of the last file separator to use it when entering a new
			 * address
			 * 
			 */
			String some = "" + SequentialREPL.currentWorkingDirectory.charAt(i);
			if (some.equals(FILE_SEPARATOR)) {
				lastFileSeparator = i;
			}
		}
<<<<<<< HEAD:src/cs131/pa1/filter/sequential/cd.java
		if (line.equals("..")) { // depends on the command builder implementation
=======
		if (line.equals("")) { // depends on the command builder implementation
>>>>>>> bb575909852cd4f9bcc616c85a6ac238c7c82536:src/cs131/pa1/cd.java
			/*
			 * goes back to parent directory
			 */
			SequentialREPL.setWorkingDirectory(SequentialREPL.currentWorkingDirectory.substring(0, lastFileSeparator));
<<<<<<< HEAD:src/cs131/pa1/filter/sequential/cd.java
		} else if(!line.equals("."))
=======
		} else
>>>>>>> bb575909852cd4f9bcc616c85a6ac238c7c82536:src/cs131/pa1/cd.java

		{
			Path togo = Paths.get(SequentialREPL.currentWorkingDirectory + FILE_SEPARATOR + line);
			/*
			 * creates a path with the address given and checks if it exists in the
			 * directory
			 */
			if (Files.exists(togo)) {
				SequentialREPL.setWorkingDirectory(SequentialREPL.currentWorkingDirectory += FILE_SEPARATOR + line);
			} else {
				System.out.print(Message.DIRECTORY_NOT_FOUND.with_parameter(line));
			}
		}
<<<<<<< HEAD:src/cs131/pa1/filter/sequential/cd.java
=======
	}

	@Override
	protected String processLine(String line) {
		return null;
>>>>>>> bb575909852cd4f9bcc616c85a6ac238c7c82536:src/cs131/pa1/cd.java
	}

	@Override
	protected String processLine(String line) {
		return null;
	}

}