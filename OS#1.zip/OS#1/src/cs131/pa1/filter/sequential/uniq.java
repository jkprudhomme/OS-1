package cs131.pa1.filter.sequential;

import java.io.IOException;
import java.nio.file.*;
import java.util.*;

import cs131.pa1.filter.Message;

public class uniq extends SequentialFilter {
	private String line;
	
	public uniq(String line){
		this.line = line;
	}
	@Override
	public void process() {
		/*
		 * @see grep.java
		 * same idea just filters out duplicates
		 */
		output = new LinkedList<String>();
		String parts[] = line.trim().split(" ");
		if (parts.length == 1) {
			if (input.isEmpty()) {
				System.out.print(Message.REQUIRES_INPUT.with_parameter(line));
			} else {
//				String disAttach[]=input.poll().split("\n");
//				for (int i=0; i<disAttach.length;i++){
//					if (!output.contains(disAttach[i])) {
//						output.add(disAttach[i]);
//					}
//				}
				String[] disAttach=input.poll().split("\n");
				Set<String> hashee = new LinkedHashSet<String>(); //create a new hash set
				List<String> disAttachToList=Arrays.asList(disAttach); //convert disAttach to a list
				hashee.addAll(disAttachToList); //add disAttach, the list, into the hash set

				for(String lines : hashee){
					output.add(lines);
				}

				
			}
		} else {
			System.out.print(Message.INVALID_PARAMETER.with_parameter(line));

		}
//		return output.toString().substring(1, output.toString().length() - 1);
	}
	@Override
	protected String processLine(String line) {
		// TODO Auto-generated method stub
		return null;
	}

}
