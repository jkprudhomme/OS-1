package cs131.pa1.filter.sequential;

import java.io.IOException;
import java.nio.file.*;
import java.util.LinkedList;
import java.util.Scanner;

import cs131.pa1.filter.Message;

public class wc extends SequentialFilter {
	private String line;
	
	public wc(String line){
		this.line = line;
	}
	
	
	@Override
	public void process(){
		/*
		 * @see grep.java & uniq.java
		 * @warning: long runtime
		 */
		output = new LinkedList<String>();
		int LC = 0, WC = 0, CC = 0;
		String parts[] = line.trim().split(" ");
		if (parts.length ==1) {
			if (input.isEmpty()) {
				System.out.print(Message.REQUIRES_INPUT.with_parameter(line));
			} else {
				while (!input.isEmpty()) {
					String[] countLines = input.poll().split("\n"); //WILL COUNT .txt, etc.
//					LC = countLines.length;
					for (int i = 0; i < countLines.length; i++) {
						if(!countLines[i].isEmpty()){
							LC++;
							String lines = countLines[i].replaceAll("\\s","__space__");
//							System.out.println(lines);
							String[] countWords = lines.split(" ");
							
//							WC += countWords.length;
							for (int j = 0; j < countWords.length; j++) {
								if(!countWords[j].equals("__space__")){
									WC++;
									CC += countWords[j].length();
								}else{
									CC++;
								}
							}
						}
					}
				}
				output.add(LC + " " + WC + " " + CC);
			}
		} else {
			System.out.print(Message.INVALID_PARAMETER.with_parameter(line));

		}
//		return output.toString().substring(1, output.toString().length() - 1);
	}


	@Override
	protected String processLine(String line) {
		// TODO Auto-generated method stub
		return null;
	}


}
