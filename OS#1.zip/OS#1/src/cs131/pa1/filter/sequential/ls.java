package cs131.pa1.filter.sequential;

import java.io.File;
import java.lang.reflect.Array;

import cs131.pa1.filter.Message;

public class ls extends SequentialFilter {
	
	private String line;
	
	public ls(String line){
		this.line = line;
	}
	
	@Override
	public void process() {
		File address = new File(line);
		String[] children = address.list(); //java finds all inside files/folders in directory
		
		for (int i = 0; i < children.length; i++) {
			output.add(children[i]); 
		}
			
//		if (children == null) { 
//			System.out.println(Message.CANNOT_HAVE_OUTPUT.with_parameter(line));
//		} else {
//			for (int i = 0; i < children.length; i++) {
//				output.add(children[i]); 
//			}
//		}
//		System.out.print(output.toString().substring(1, output.toString().length()-1));
	}

	@Override
	protected String processLine(String line) {
		// TODO Auto-generated method stub
		return null;
	}

}
