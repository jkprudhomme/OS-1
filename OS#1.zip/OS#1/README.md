In this programming assignment you will have to work in groups of two. You should
divide the work (eg. by commands) and keep track of who coded what. Please include a
README file stating who did which part of the assignment.

Jordan Prudhomme - shell core - SequentialCommandBuilder.java, SequentialREPL.java, (linked both projects-- edited commands to do so)

Osamah Mandawi - commands - cat.java, cd.java, grep.java, ls.java, pwd.java, uniq.java, wc.java, write.java, (general commenting & clean-up)
