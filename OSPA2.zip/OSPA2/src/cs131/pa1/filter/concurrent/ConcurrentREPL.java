package cs131.pa1.filter.concurrent;

import cs131.pa1.filter.Message;

import java.awt.List;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

public class ConcurrentREPL {

	static String currentWorkingDirectory;
	static Boolean background = false;
	static HashMap<Integer,ArrayList<Thread>> back = new HashMap<Integer,ArrayList<Thread>>();
	static ArrayList<Thread> subc;
	
	
	public static void main(String[] args){
		currentWorkingDirectory = System.getProperty("user.dir");
		Scanner s = new Scanner(System.in);
		System.out.print(Message.WELCOME);
		String command;
		while(true) {
			//obtaining the command from the user
			System.out.print(Message.NEWCOMMAND);
			command = s.nextLine();
			String[] subcommands = command.trim().split(" ");
			if(command.equals("exit")) {
				break;
			} else if(command.equals("repl_jobs")){
				repl_jobs();
			} else if(subcommands[0].equals("kill")){
//				String[] details = command.trim().split(" ");
				if(subcommands.length<2){
					System.out.print(Message.REQUIRES_PARAMETER.with_parameter(command));
				}else{
					try{
						Integer.parseInt(subcommands[1]);
						kill(Integer.parseInt(subcommands[1]));
					} catch(NumberFormatException ex){
						System.out.print(Message.INVALID_PARAMETER.with_parameter(command));
					}
				}
			}else if(!command.trim().equals("")) {
				String[] details = command.trim().split(" ");
				if(details[details.length-1].equals("&")){
					command = command.trim();
					command = command.substring(0,command.length()-1);
					background = true;
				}
				
				//building the filters list from the command
				ConcurrentFilter filterlist = ConcurrentCommandBuilder.createFiltersFromCommand(command);
				
				if(background){
					subc = new ArrayList<Thread>();
					back.put(back.size()+1, subc);
				}
				
				while(filterlist != null) {
					Thread currentThread = new Thread(filterlist,command);
					currentThread.start();
					
					if(!background){
						try {
							currentThread.join();
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
					}else{
						subc.add(currentThread);
					}
					background = false;
				
					
					filterlist = (ConcurrentFilter) filterlist.getNext();
				}
			}
		}
		s.close();
		back.clear();
		System.out.print(Message.GOODBYE);
	}
	
	static void kill(int num){
		for(Thread subc : back.get(num)){
			if(subc.isAlive()){
				subc.interrupt();
			}
		}
		back.remove(num);
	}
	
	static void repl_jobs(){
		for(int i : back.keySet()){
			ArrayList<Thread> backSub= back.get(i);
//			System.out.println("\t" +(i+1) + ". " + back.get(i).getName() + "&");
			if(backSub.get(backSub.size()-1).isAlive()){
				System.out.println("\t" +(i) + ". " + backSub.get(0).getName() + "&");
			}
		}
	}

}