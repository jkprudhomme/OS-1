package cs131.pa1.filter.concurrent;

import cs131.pa1.filter.Message;

import java.awt.List;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

public class ConcurrentREPL {

	static String currentWorkingDirectory;
	static Boolean background = false;
	static ArrayList<Thread> back = new ArrayList<Thread>();
	
	
	public static void main(String[] args){
		currentWorkingDirectory = System.getProperty("user.dir");
		Scanner s = new Scanner(System.in);
		System.out.print(Message.WELCOME);
		String command;
		while(true) {
			//obtaining the command from the user
			System.out.print(Message.NEWCOMMAND);
			command = s.nextLine();
			if(command.equals("exit")) {
				break;
			} else if(command.equals("repl_jobs")){
				repl_jobs();
			} else if(command.contains("kill")){
				String[] details = command.trim().split(" ");
				kill(Integer.parseInt(details[1]));
			}else if(!command.trim().equals("")) {
				String[] details = command.trim().split(" ");
				if(details[details.length-1].equals("&")){
					command = command.trim();
					command = command.substring(0,command.length()-1);
					background = true;
				}
				
				//building the filters list from the command
				ConcurrentFilter filterlist = ConcurrentCommandBuilder.createFiltersFromCommand(command);
				while(filterlist != null) {
					
					Thread currentThread = new Thread(filterlist,command);
					currentThread.start();
					
					if(!background){
						try {
							currentThread.join();
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
					}else{
						back.add(0,currentThread);
					}
					background = false;
					
					filterlist = (ConcurrentFilter) filterlist.getNext();
				}
			}
		}
		s.close();
		back.clear();
		System.out.print(Message.GOODBYE);
	}
	
	static void kill(int num){
		back.get(num).interrupt();
	}
	
	static void repl_jobs(){
		for(int i = 0; i < back.size();i++){
//			System.out.println("\t" +(i+1) + ". " + back.get(i).getName() + "&");
			if(back.get(i).isAlive()){
				System.out.println("\t" +(i+1) + ". " + back.get(i).getName() + "&");
			}	
		}
	}

}