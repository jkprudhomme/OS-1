package cs131.pa1.filter.concurrent;
import java.util.Queue;
import java.util.concurrent.LinkedBlockingQueue;

import cs131.pa1.filter.Filter;


public abstract class ConcurrentFilter extends Filter implements Runnable {
	
	protected Queue<String> input;
	protected Queue<String> output;
	
	@Override
	public void setPrevFilter(Filter prevFilter) {
		prevFilter.setNextFilter(this);
	}
	
	@Override
	public void setNextFilter(Filter nextFilter) {
		if (nextFilter instanceof ConcurrentFilter){
			ConcurrentFilter sequentialNext = (ConcurrentFilter) nextFilter;
			this.next = sequentialNext;
			sequentialNext.prev = this;
			if (this.output == null){
				this.output = new LinkedBlockingQueue<String>();
			}
			sequentialNext.input = this.output;
		} else {
			throw new RuntimeException("Should not attempt to link dissimilar filter types.");
		}
	}
	
	public Filter getNext() {
		return next;
	}
	
	public Filter getPrev() {
		return prev;
	}
	
	public void process(){
		while (!input.isEmpty()){
			String line = input.poll();
			String processedLine = processLine(line);
			if (processedLine != null){
				output.add(processedLine);
			}
		}
		output.add("__poisonpill__");
	}
	
	
//	NEEDS WORK
	@Override
	public boolean isDone() {
		if(input==null){
			return true;
		}else if(input.peek().equals("__poisonpill__")){
			return true;
		}else{
			return false;
		}
//		return input.size() == 0;
	}
	
	@Override
	public void run() {
		while(!isDone()){
			process();
		}
		output.add("__poisonpill__");
	}
	
	protected abstract String processLine(String line);
	
}
