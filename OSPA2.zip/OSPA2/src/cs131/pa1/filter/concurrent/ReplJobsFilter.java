package cs131.pa1.filter.concurrent;

public class ReplJobsFilter extends ConcurrentFilter {

	@Override
	protected String processLine(String line) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		
	}

}
