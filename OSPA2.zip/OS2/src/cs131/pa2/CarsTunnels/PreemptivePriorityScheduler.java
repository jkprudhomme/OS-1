package cs131.pa2.CarsTunnels;

import java.util.*;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import cs131.pa2.Abstract.Tunnel;
import cs131.pa2.Abstract.Vehicle;
import cs131.pa2.Abstract.Log.Log;

public class PreemptivePriorityScheduler extends Tunnel {
	private Collection<Tunnel> tunnels;
	private PriorityQueue<Integer> waiting;
	private HashMap<Vehicle, Tunnel> inside;
	private HashMap<Tunnel,ArrayList<Vehicle>> matches;
	protected final Lock lock = new ReentrantLock();
	protected final Condition isTopPriority = lock.newCondition();
	protected final Condition thereIsAnAmbulance = lock.newCondition();

	public PreemptivePriorityScheduler(String label, Collection<Tunnel> tunnels, Log log) {
		super(label, log);
		this.tunnels = tunnels;
		waiting = new PriorityQueue<Integer>(Collections.reverseOrder());
		inside = new HashMap<Vehicle, Tunnel>();
		matches = new HashMap<Tunnel,ArrayList<Vehicle>>();
		for(Tunnel tunnel: tunnels){
			matches.put(tunnel, new ArrayList<Vehicle>());
		}
	}

	/*
	 * Uses a lock to make sure only one tread accesses the priorityqueue at a time. 
	 * Each vehicle has its priority added to the queue immediately. Then, while the vehicle does not have the highest priority
	 * or all the tunnels are full, we have the thread await. Once the vehicle enters, we remove its priority from the queue 
	 * and return true
	 */
	@Override
	public boolean tryToEnterInner(Vehicle vehicle) {
		lock.lock();
		waiting.add(vehicle.getPriority());
		try {
			while ((vehicle.getPriority() < waiting.peek())||tunnelsfull(vehicle)) {
				isTopPriority.await();
			}
			waiting.remove(vehicle.getPriority());
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			lock.unlock();
		}
		return true;
	}

/*	Checks if there is an available tunnel for the vehicle to enter. If vehicle is an ambulance, 
*   changes all vehicles in its tunnel to know there is an ambulance in their tunnel and signals them
*/   
	private boolean tunnelsfull(Vehicle vehicle) {
		if(vehicle instanceof Ambulance){
			for (Tunnel tunnel : tunnels) {
				if (tunnel.tryToEnter(vehicle)) {
					inside.put(vehicle, tunnel);
					for(Vehicle normal: matches.get(tunnel)){
						normal.setAmb(true);
						normal.signalAllWait();
					}
					return false;
				}
			}
		}else{
			for (Tunnel tunnel : tunnels) {
				if (tunnel.tryToEnter(vehicle)) {
					inside.put(vehicle, tunnel);
					vehicle.addTunnel(tunnel);
					matches.get(tunnel).add(vehicle);
					return false;
				}
			}
		}
		return true;
	}

	/*
	 * 	Removes vehicle from its tunnel and signals all threads that they can try to enter again
	 *  If vehicle is an ambulance, changes all vehicles in its tunnel to know the ambulance left and signals them
	 */
	@Override
	public void exitTunnelInner(Vehicle vehicle) {
		lock.lock();
		try {
			Tunnel tunnel = inside.get(vehicle);
			tunnel.exitTunnel(vehicle);
			if (vehicle instanceof Ambulance) {
				for(Vehicle normal: matches.get(tunnel)){
					normal.setAmb(false);
					normal.signalAll();
				}
				isTopPriority.signalAll();
			}else{
				if(!vehicle.getAmb()) {
					matches.get(tunnel).remove(vehicle);
					inside.remove(vehicle);
				}
			}
		} finally {
			lock.unlock();
		}
	}
}