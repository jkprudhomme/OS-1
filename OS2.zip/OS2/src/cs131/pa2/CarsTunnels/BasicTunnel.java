package cs131.pa2.CarsTunnels;

import cs131.pa2.Abstract.*;

public class BasicTunnel extends Tunnel{

	private int cars;
	private Boolean sled;
	private Direction dir;
	
	public BasicTunnel(String name) {
		super(name);
		cars = 0;
		sled = false;
		dir = null;
	}

	@Override
	public synchronized boolean tryToEnterInner(Vehicle vehicle) {
		if(vehicle instanceof Car){
			if(cars < 3 && !sled){
				if(cars>0){
					if(vehicle.getDirection() == dir){
						cars++;
						return true;
					}
				}else{
					cars++;
					dir = vehicle.getDirection();
					return true;
				}
			}else{
				return false;
			}
		}else if(vehicle instanceof Sled){
			if(cars == 0 && !sled){
				sled = true;
				return true;
			}else{
				return false;
			}
		}else{
			return false;
		}
		return false;
	}

	@Override
	public synchronized void exitTunnelInner(Vehicle vehicle) {
		if(vehicle instanceof Car){
			cars--;
		}else if(vehicle instanceof Sled){
			sled = false;
		}
		
	}
	
}
